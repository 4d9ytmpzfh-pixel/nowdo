NOWDO PWA 安装说明

把这个文件夹里的所有内容上传到同一个 GitHub Pages 仓库根目录：
- index.html
- manifest.json
- sw.js
- icons/ 文件夹

然后在 iPad Safari 打开你的 GitHub Pages 网页，点分享按钮 → Add to Home Screen / 添加到主屏幕。
从主屏幕图标打开时，会以独立 App 形式运行，不显示 Safari 地址栏。

缓存说明：
sw.js 会缓存 index.html、manifest.json 和图标。第一次打开需要联网；之后会优先从缓存加载，提高速度和稳定性。
如果你之后更新代码但 iPad 还是显示旧版，可以改 sw.js 顶部 NOWDO_CACHE 的版本名，例如 nowdo-pwa-v2，然后重新上传。
